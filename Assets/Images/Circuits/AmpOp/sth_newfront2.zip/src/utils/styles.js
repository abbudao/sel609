import React from 'react' ;
import styled from 'styled-components'; 

export const Container = styled.div`
margin: 0 0;
flex-wrap: no-wrap;
display: flex;
align-items: center;
justify-content: space-around;
`
export const SmallContainer = styled.div`
display: flex;
justify-content: space-evenly;
`

export const ShowOnlyOnDesktop = styled.div`
display: none;
@media (min-width: 700px) 
{
display:block;
}
`
