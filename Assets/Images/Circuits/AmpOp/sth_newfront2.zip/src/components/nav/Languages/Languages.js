import React from 'react';
import styled from 'styled-components';
const StyledButton = styled.button`
background:gray;
`
const Languages = () => (
  <StyledButton> Português ></StyledButton>
)

export default Languages;
