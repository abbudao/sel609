import React from 'react';
import styled from 'styled-components'
import Help from 'components/nav/Help/Help'
import Search from 'components/nav/Search/Search'
import Languages from 'components/nav/Languages/Languages'
import {Container,
  SmallContainer,
  ShowOnlyOnDesktop}  from 'utils/styles'

const StyledToolbar = styled.header`
position:fixed;
width:100%;
top:0;
left:0;
`
const helpToolbar= () =>(
  <ShowOnlyOnDesktop>
    <StyledToolbar>
      <Container>
        <Help/>
        <SmallContainer>
          <Search />
          <Languages />
        </SmallContainer>
      </Container>
    </StyledToolbar>
  </ShowOnlyOnDesktop>
)

export default helpToolbar;
