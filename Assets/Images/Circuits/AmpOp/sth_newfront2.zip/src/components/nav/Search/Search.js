import React from 'react';
import styled from 'styled-components';

const Search = () => (
  <input placeholder="Pesquisar"/> 
)

export default Search;
