import React from 'react';
import styled from 'styled-components';

const Help = () => (
  <a href='#'> Dúvidas? Entenda como funciona! </a>
)

export default Help;
