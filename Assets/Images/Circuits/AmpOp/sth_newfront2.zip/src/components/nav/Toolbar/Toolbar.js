import React from 'react';
import styled from 'styled-components';
import {Container, SmallContainer} from 'utils/styles';
import Logo from 'components/essential/ExtendedLogo/ExtendedLogo';
import Menu from 'components/essential/BurguerMenu/BurguerMenu';

const StyledToolbar = styled.header`
position:absolute;
width:100%;
left:0;
top:0;
background:red;
@media (min-width: 700px) 
{
margin-top:20px;
}
`

const StyledMenu = styled(Menu)`
height: 40px;
@media (min-width: 700px) 
{
display:none;
}
`

const StyledA= styled.a`
margin:12px;
color:white;
`


const StyledLogo = styled(Logo)`
max-height:40px;
`
const toolbar = (props) => (
    <StyledToolbar>
        <Container>
            <StyledMenu height={18} width={18} color="white"/>
            <StyledLogo height={1120} width={196}/>
            <SmallContainer>
                <StyledA> Início </StyledA>
                <StyledA> Missões </StyledA>
                <StyledA> Enviar Missão </StyledA>
                <StyledA> Quem Somos </StyledA>
                <StyledA> Blog </StyledA>
                <button>Enviar / Cadastrar-se </button>
            </SmallContainer>

        </Container>
    </StyledToolbar>
)
export default toolbar;
