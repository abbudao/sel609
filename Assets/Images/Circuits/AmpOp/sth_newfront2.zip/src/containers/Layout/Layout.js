import React from 'react';
import HelpToolbar from 'components/nav/HelpToolbar/HelpToolbar';
import Toolbar from 'components/nav/Toolbar/Toolbar'

class Layout extends React.Component {
  render(props) {
    return (
      <React.Fragment>
        <HelpToolbar/>
        <Toolbar/>
      </React.Fragment>
    );
  }
}

export default Layout;
